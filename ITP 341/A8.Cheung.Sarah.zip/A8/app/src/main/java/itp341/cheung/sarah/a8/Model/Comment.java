package itp341.cheung.sarah.a8.Model;

public class Comment {
    String name = "";
    String comment = "";
    String time = "";

    public Comment(){
        super();
    }

    public Comment(String name, String comment, String time) {
        this.name = name;
        this.comment = comment;
        this.time = time;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

}
