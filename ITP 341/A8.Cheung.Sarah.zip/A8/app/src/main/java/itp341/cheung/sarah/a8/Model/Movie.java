package itp341.cheung.sarah.a8.Model;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;

public class Movie implements Serializable {
    private String title, description;
    private String url = "";
    private int genre;
    private ArrayList<Comment> comments = new ArrayList<Comment>();

    public Movie(){
        super();
    }

    public Movie(String title, String description, String url, int genre) {
        this.title = title;
        this.description = description;
        this.url = url;
        this.genre = genre;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setGenre(int genre) {
        this.genre = genre;
    }

    public int getGenre() {
        return genre;
    }

    public void setComments(ArrayList<Comment> comments) {
        this.comments = comments;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public void addComment(Comment comment) {
        comments.add(comment);
    }

    public String toString() {
        if (genre == 0) {
            return "horror";
        }
        else if (genre == 1) {
            return "scifi";
        }
        else if (genre == 2) {
            return "comedy";
        }
        else if (genre == 3) {
            return "drama";
        }
        else if (genre == 4) {
            return "action";
        }
        Log.e("Movie", "Invalid genre");
        return "";
    }
}
