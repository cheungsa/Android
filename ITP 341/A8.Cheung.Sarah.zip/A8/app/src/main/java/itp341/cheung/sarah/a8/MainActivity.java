package itp341.cheung.sarah.a8;

import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.os.Bundle;
import android.widget.Button;
import android.content.Context;
import android.widget.ImageView;
import android.content.Intent;
import android.view.LayoutInflater;
import android.widget.ListView;
import android.util.Log;
import android.widget.TextView;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import com.squareup.picasso.Picasso;

import itp341.cheung.sarah.a8.Model.Movie;
import itp341.cheung.sarah.a8.Model.MovieSingleton;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();
    public static final String EXTRA_MOVIE_LIST = "com.itp341.cheung.sarah.movie";

    AdapterMovie adpt;
    Button buttonAdd;
    ListView listMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adpt = new AdapterMovie(this, R.layout.layout_list_movie, MovieSingleton.getSingleton().getMovies());
        buttonAdd = (Button) findViewById(R.id.button_add);
        listMovie =(ListView)findViewById(R.id.list_movie);
        listMovie.setAdapter(adpt);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, CreateActivity.class);
                startActivityForResult(i, 1);
            }
        });
    }

    private class AdapterMovie extends ArrayAdapter<Movie> {
        public AdapterMovie(Context context, int resource, ArrayList<Movie> objects) {
            super(context, resource, objects);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.layout_list_movie, parent, false);
            }

            Button buttonFindOut = (Button) convertView.findViewById(R.id.button_find_out_more);
            ImageView imageMovie = (ImageView) convertView.findViewById(R.id.image_movie);
            TextView textDescription = (TextView) convertView.findViewById(R.id.text_description);
            TextView textTitle = (TextView) convertView.findViewById(R.id.text_title);

            Movie movie = getItem(position);
            buttonFindOut.setTag(position);
            textDescription.setText(movie.getDescription());
            textTitle.setText(movie.getTitle());

            if (movie.getUrl().contains("http")) {
                Log.d(TAG, "Url is: " + movie.getUrl());
                Picasso.get()
                        .load(movie.getUrl())
                        .placeholder(R.drawable.mocha)
                        .resize(400, 200)
                        .centerCrop()
                        .into(imageMovie);
            }
            else {
                setImage(movie.toString(), imageMovie);
            }

            buttonFindOut.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(MainActivity.this, DetailActivity.class);
                    i.putExtra(EXTRA_MOVIE_LIST, (Integer) view.getTag());
                    startActivityForResult(i, 2);
                }
            });

            return convertView;
        }
    }

    private void setImage(String genre, ImageView img){
        Log.e(TAG, "Genre is: " + genre);
        if (genre.contains("horror")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.horror,
                    getApplicationContext().getTheme()));
        }
        else if (genre.contains("scifi")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.scifi,
                    getApplicationContext().getTheme()));
        }
        else if (genre.contains("comedy")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.comedy,
                    getApplicationContext().getTheme()));
        }
        else if (genre.contains("drama")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.drama,
                    getApplicationContext().getTheme()));
        }
        else if (genre.contains("action")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.action,
                    getApplicationContext().getTheme()));
        }
        else {
            Log.e(TAG, "Invalid genre");
        }
    }

    private void refresh(){
        adpt.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            refresh();
        }
    }

}
