package itp341.cheung.sarah.a8;

import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.os.Bundle;
import android.widget.Button;
import android.content.Context;
import android.widget.EditText;
import android.widget.ImageView;
import android.view.LayoutInflater;
import android.widget.ListView;
import android.util.Log;
import android.widget.TextView;
import android.view.View;
import android.view.ViewGroup;
import android.text.format.DateFormat;

import java.util.ArrayList;
import com.squareup.picasso.Picasso;

import itp341.cheung.sarah.a8.Model.Comment;
import itp341.cheung.sarah.a8.Model.Movie;
import itp341.cheung.sarah.a8.Model.MovieSingleton;

public class DetailActivity extends AppCompatActivity {
    private static final String TAG = DetailActivity.class.getSimpleName();
    
    Button buttonComment;
    EditText editComment;
    EditText editName;
    ImageView imageMovie;
    ListView listComments;
    TextView textMovieTitle;
    TextView textMovieDescription;
    
    int movieIndex;

    AdapterComment adpt;
    ArrayList<Comment> comments;
    Movie currMovie = new Movie();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        buttonComment = (Button) findViewById(R.id.button_comment);
        editComment = (EditText) findViewById(R.id.edit_comment);
        editName = (EditText)findViewById(R.id.edit_name);
        imageMovie = (ImageView) findViewById(R.id.image_detail_movie);
        listComments = (ListView) findViewById(R.id.list_comment);
        textMovieTitle = (TextView) findViewById(R.id.text_title_detail);
        textMovieDescription = (TextView) findViewById(R.id.text_description_detail);

        movieIndex = getIntent().getIntExtra(MainActivity.EXTRA_MOVIE_LIST, -1);
        currMovie = MovieSingleton.getSingleton().getMovie(movieIndex);

        textMovieDescription.setText(MovieSingleton.getSingleton().getMovie(movieIndex).getDescription());
        textMovieTitle.setText(MovieSingleton.getSingleton().getMovie(movieIndex).getTitle());
        setImage(MovieSingleton.getSingleton().getMovie(movieIndex).toString(), imageMovie);

        if (currMovie.getComments() == null) {
            currMovie.addComment(new Comment());
        }
        comments = currMovie.getComments();

        adpt = new DetailActivity.AdapterComment(this, R.layout.layout_list_comment, MovieSingleton.getSingleton().getMovie(movieIndex).getComments());
        listComments.setAdapter(adpt);

        buttonComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CharSequence timestamp = DateFormat.format("MM-dd-yyyy hh:mm:ss", new java.util.Date());
                Comment comment = new Comment(editName.getText().toString(),
                                                editComment.getText().toString(),
                                                timestamp.toString());
                MovieSingleton.getSingleton().getMovie(movieIndex).addComment(comment);
                editName.getText().clear();
                editComment.getText().clear();
                adpt.notifyDataSetChanged();
            }
        });
    }



    private void setImage(String genre, ImageView img){
        Log.e(TAG, "Genre is: " + genre);
        if (currMovie.getUrl().contains("http")) {
            Log.d(TAG, "Url is: " + currMovie.getUrl());
            Picasso.get()
                    .load(currMovie.getUrl())
                    .placeholder(R.drawable.mocha)
                    .resize(400, 200)
                    .centerCrop()
                    .into(img);
        }
        else if (genre.contains("horror")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.horror,
                    getApplicationContext().getTheme()));
        }
        else if (genre.contains("scifi")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.scifi,
                    getApplicationContext().getTheme()));
        }
        else if (genre.contains("comedy")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.comedy,
                    getApplicationContext().getTheme()));
        }
        else if (genre.contains("drama")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.drama,
                    getApplicationContext().getTheme()));
        }
        else if (genre.contains("action")){
            img.setImageDrawable(getResources().getDrawable(R.drawable.action,
                    getApplicationContext().getTheme()));
        }
        else {
            Log.e(TAG, "Invalid genre");
        }

    }

    private class AdapterComment extends ArrayAdapter<Comment> {
        public AdapterComment(Context context, int resource, ArrayList<Comment> comments) {
            super(context, resource, comments);
        }

        @Override
        public View getView(int pos, View v, ViewGroup vg) {
            if (v == null) {
                v = LayoutInflater.from(getContext()).inflate(R.layout.layout_list_comment, vg, false);
            }
            TextView textComment = v.findViewById(R.id.text_comment);
            TextView textTime = v.findViewById(R.id.text_time);
            TextView textName = v.findViewById(R.id.text_name);

            Comment comm = getItem(pos);
            textTime.setText(comm.getTime());
            textComment.setText(comm.getComment());
            textName.setText(comm.getName());

            return v;
        }
    }
}
