package itp341.cheung.sarah.a8.Model;

import android.content.Context;
import android.util.Log;
import java.util.ArrayList;

public class MovieSingleton {
    private static MovieSingleton singleton;
    private ArrayList<Movie> movies; // data source
    private Context context; // need the context (android-specific)

    // private singleton constructor
    private MovieSingleton() {
        movies = new ArrayList<Movie>();
    }

    // singleton get method
    public static MovieSingleton getSingleton() {
        if (singleton == null) {
            singleton = new MovieSingleton();
        }
        return singleton;
    }

    public int getNumMovies() {
        return movies.size();
    }

    public ArrayList<Movie> getMovies() {
        return movies;
    }

    public Movie getMovie(int index) {
        if (index < 0 || index >= movies.size()) {
            Log.d("ERROR", "getMovie: index out of bounds");
            return null;
        }
        return movies.get(index);
    }

    public void addMovie(Movie movie) {
        movies.add(movie);
    }

    public void removeMovie(Movie movie) {
        movies.remove(movie);
    }

    public void addMovieComment(int index, Comment comment) {
        if (index < 0 || index >= movies.size()) {
            Log.d("ERROR", "addMovieComment: index out of bounds");
            return;
        }
        movies.get(index).addComment(comment);
    }

}
