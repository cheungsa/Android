package itp341.cheung.sarah.a7;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.support.annotation.IdRes;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import itp341.cheung.sarah.a7.Model.Card;
import itp341.cheung.sarah.a7.Model.Ticket;

public class MainActivity extends AppCompatActivity {
    public static final String TICKET_VALUE = "itp341.cheung.sarah.a6.TICKET_VALUE";
    public static final String PRIORITY_ID_VALUE = "itp341.cheung.sarah.a6.PRIORITY_ID_VALUE";
    public static final String TICKET_ID_VALUE = "itp341.cheung.sarah.a6.TICKET_ID_VALUE";
    private Card card;
    private Ticket ticket;

    private int numTicketsSold = 0;
    private boolean isEditAgain = false;
    private boolean isSaved = false;

    private TextView ticketCountTextView;
    private Spinner spinnerStartLocation;
    private Spinner spinnerEndLocation;
    private RadioGroup radioTicketType;
    private RadioGroup radioPriorityType;
    private Button buttonUseCard;
    private Button buttonVerify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ticket = new Ticket("None", "None", "None", "None");
        card = new Card("None", "None");

        ticketCountTextView = (TextView) findViewById(R.id.text_tickets_sold_count);
        spinnerStartLocation = (Spinner) findViewById(R.id.spinner_start);
        spinnerEndLocation = (Spinner) findViewById(R.id.spinner_end);
        radioTicketType = (RadioGroup) findViewById(R.id.radio_ticket);
        radioPriorityType = (RadioGroup) findViewById(R.id.radio_priority);
        buttonUseCard = (Button) findViewById(R.id.button_use_card);
        buttonVerify = (Button) findViewById(R.id.button_verify);

        final Intent intentMain = getIntent();
        isSaved = intentMain.getBooleanExtra(CardActivity.IS_CARD_SAVED_VALUE, false);
        isEditAgain = intentMain.getBooleanExtra(ViewOrderActivity.EDIT_AGAIN_VALUE, false);
        if (isEditAgain || isSaved) {
            card = (Card)intentMain.getExtras().getSerializable(CardActivity.CARD_VALUE);
            ticket = (Ticket) intentMain.getExtras().getSerializable(MainActivity.TICKET_VALUE);
            RadioButton rbtnPriority = (RadioButton)radioPriorityType.getChildAt(ticket.getPriorityTypeId());
            rbtnPriority.setChecked(true);
            //radioPriorityType.check(ticket.getPriorityTypeId());
            RadioButton rbtnTicket = (RadioButton)radioTicketType.getChildAt(ticket.getTripTypeId());
            rbtnTicket.setChecked(true);
            //radioTicketType.check(ticket.getTripTypeId());
            spinnerStartLocation.setSelection(ticket.getStartingLocationId());
            spinnerEndLocation.setSelection(ticket.getEndingLocationId());
        }

        spinnerStartLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                ticket.setStartingLocation(adapterView.getItemAtPosition(i).toString());
                ticket.setStartingLocationId(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinnerEndLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                ticket.setEndingLocation(adapterView.getItemAtPosition(i).toString());
                ticket.setEndingLocationId(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        radioTicketType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                RadioButton rbtn = (RadioButton)radioGroup.findViewById(i);
                if (rbtn != null) {
                    ticket.setTripType(rbtn.getText().toString());
                    ticket.setTripTypeId(i);
                }
            }
        });

        radioPriorityType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                RadioButton rbtn = (RadioButton)radioGroup.findViewById(i);
                if (rbtn != null) {
                    ticket.setPriorityType(rbtn.getText().toString());
                    ticket.setPriorityTypeId(i);
                }
            }
        });

        buttonUseCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCard = new Intent(getApplicationContext(), CardActivity.class);
                intentCard.putExtra(CardActivity.CARD_VALUE, card);
                intentCard.putExtra(TICKET_VALUE, ticket);
                if (isEditAgain || isSaved) {
                    intentMain.putExtra(ViewOrderActivity.EDIT_AGAIN_VALUE, true);
                }
                if (isSaved) {
                    intentMain.putExtra(CardActivity.IS_CARD_SAVED_VALUE, true);
                }
                startActivityForResult(intentCard,1);
            }
        });

        buttonVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentOrder = new Intent(getApplicationContext(), ViewOrderActivity.class);
                intentOrder.putExtra(CardActivity.CARD_VALUE, card);

                ticket = new Ticket(ticket.getStartingLocation(), ticket.getEndingLocation(), ticket.getTripType(), ticket.getPriorityType());
                intentOrder.putExtra(TICKET_VALUE, ticket);

                startActivityForResult(intentOrder, 2);
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Came from Make Edit
        if (requestCode == 2 && resultCode == 3) {
            Toast.makeText(getApplicationContext(),
                    getResources().getString(R.string.make_changes),
                    Toast.LENGTH_LONG).show();

            ticket = (Ticket) data.getExtras().getSerializable(TICKET_VALUE);
            card = (Card) data.getExtras().getSerializable(CardActivity.CARD_VALUE);
            fillOrder();

            Log.d("Message", ticket.toString());
        }

        // Came from Edit Card
        if (requestCode == 1 && resultCode == 5) {
            card = (Card) data.getExtras().getSerializable(CardActivity.CARD_VALUE);
            ticket = (Ticket) data.getExtras().getSerializable(TICKET_VALUE);
            fillOrder();
        }

        // Came from Purchase
        if (requestCode == 2 && resultCode == 2) {
            boolean isPurchased = data.getBooleanExtra(ViewOrderActivity.VERIFIED_VALUE, false);
            if (isPurchased) {
                Toast.makeText(getApplicationContext(),
                        getResources().getString(R.string.thank_you),
                        Toast.LENGTH_LONG).show();
                numTicketsSold++;
                ticketCountTextView.setText(String.valueOf(numTicketsSold));
                clearOrder();
            }
            else {
                fillOrder();
            }
        }
    }

    private void clearOrder() {
        radioTicketType.clearCheck();
        radioPriorityType.clearCheck();
        spinnerStartLocation.setSelection(0);
        spinnerEndLocation.setSelection(0);
    }

    private void fillOrder() {
        radioTicketType.check(ticket.getTripTypeId());
        radioPriorityType.check(ticket.getPriorityTypeId());
        spinnerStartLocation.setSelection(ticket.getStartingLocationId());
        spinnerEndLocation.setSelection(ticket.getEndingLocationId());
        ticketCountTextView.setText(String.valueOf(numTicketsSold));
    }

}
