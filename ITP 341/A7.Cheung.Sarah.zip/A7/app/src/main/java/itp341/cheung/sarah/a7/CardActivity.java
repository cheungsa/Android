package itp341.cheung.sarah.a7;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import itp341.cheung.sarah.a7.Model.Card;
import itp341.cheung.sarah.a7.Model.Ticket;

public class CardActivity extends AppCompatActivity{
    public static final String CARD_VALUE = "itp341.cheung.sarah.a6.CARD_VALUE";
    public static final String IS_CARD_SAVED_VALUE = "itp341.cheung.sarah.a6.EDIT_AGAIN_VALUE";

    private EditText editCardNumber;
    private EditText editCardName;
    private Button buttonSaveCard;

    private Card currCard;
    private Ticket ticket_card;
    private boolean isEditAgain;
    private boolean isSaved;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);

        Intent intentCard_card = getIntent();
        currCard = new Card("None", "None");

        editCardNumber = (EditText) findViewById(R.id.edit_card_number);
        editCardName = (EditText) findViewById(R.id.edit_card_name);
        buttonSaveCard = (Button) findViewById(R.id.button_save_card);

        ticket_card = (Ticket) intentCard_card.getExtras().getSerializable(MainActivity.TICKET_VALUE);
        isEditAgain = intentCard_card.getBooleanExtra(ViewOrderActivity.EDIT_AGAIN_VALUE, false);
        isSaved = intentCard_card.getBooleanExtra(IS_CARD_SAVED_VALUE, false);
        if (isEditAgain || isSaved) {
            currCard = (Card) intentCard_card.getExtras().getSerializable(CardActivity.CARD_VALUE);
            editCardName.setText(currCard.getName());
            editCardNumber.setText(currCard.getNumber());
        }
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String name = preferences.getString("Name", "");
        String number = preferences.getString("Number", "");
        if(!name.equals("")){
            editCardName.setText(name);
            currCard.setName(name);
        }
        if(!number.equals("")){
            editCardNumber.setText(number);
            currCard.setNumber(number);
        }

        buttonSaveCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currCard.setNumber(editCardNumber.getText().toString());
                currCard.setName(editCardName.getText().toString());

                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("Number",editCardNumber.getText().toString());
                editor.putString("Name",editCardName.getText().toString());
                editor.apply();

                if (isEditAgain) {
                    Intent i = new Intent(getApplicationContext(), ViewOrderActivity.class);
                    i.putExtra(MainActivity.TICKET_VALUE, ticket_card);
                    i.putExtra(CARD_VALUE, currCard);
                    i.putExtra(IS_CARD_SAVED_VALUE, true);
                    setResult(4, i);
                    finish();
                }
                else {
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    i.putExtra(MainActivity.TICKET_VALUE, ticket_card);
                    i.putExtra(CARD_VALUE, currCard);
                    i.putExtra(ViewOrderActivity.EDIT_AGAIN_VALUE, isEditAgain);
                    i.putExtra(IS_CARD_SAVED_VALUE, true);
                    setResult(5, i);
                    finish();
                }
            }
        });

        editCardNumber.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                currCard.setNumber(v.getText().toString());
                return true;
            }
        });

        editCardName.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                currCard.setName(v.getText().toString());
                return true;
            }
        });

    }
}
