package itp341.cheung.sarah.a7.Model;

import java.io.Serializable;

public class Ticket implements Serializable{

    private String startingLocation;
    private String endingLocation;
    private String tripType;
    private String priorityType;
    private int tripTypeId;
    private int priorityTypeId;
    private int startingLocationId;
    private int endingLocationId;

    public Ticket(String startingLocation, String endingLocation, String tripType, String priorityType) {
        this.startingLocation = startingLocation;
        this.endingLocation = endingLocation;
        this.tripType = tripType;
        this.priorityType = priorityType;
    }

    public String getStartingLocation() {
        return startingLocation;
    }

    public void setStartingLocation(String startingLocation) {
        this.startingLocation = startingLocation;
    }

    public void setStartingLocationId(int id) { startingLocationId = id; }

    public int getStartingLocationId() { return startingLocationId; }

    public String getEndingLocation() {
        return endingLocation;
    }

    public void setEndingLocation(String endingLocation) {
        this.endingLocation = endingLocation;
    }

    public void setEndingLocationId(int id) { endingLocationId = id; }

    public int getEndingLocationId() { return endingLocationId; }

    public void setTripTypeId(int id) { tripTypeId = id; }

    public int getTripTypeId() { return tripTypeId; }

    public String getTripType() {
        return tripType;
    }

    public void setTripType(String tripType) {
        this.tripType = tripType;
    }

    public void setPriorityTypeId(int id) { priorityTypeId = id; }

    public int getPriorityTypeId() { return priorityTypeId; }

    public String getPriorityType() {
        return priorityType;
    }

    public void setPriorityType(String priorityType) {
        this.priorityType = priorityType;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "startingLocation='" + startingLocation + '\'' +
                "startingLocationId='" + startingLocationId + '\'' +
                ", endingLocation='" + endingLocation + '\'' +
                ", endingLocationId='" + endingLocationId + '\'' +
                ", tripType='" + tripType + '\'' +
                ", tripTypeId='" + tripTypeId + '\'' +
                ", priorities='" + priorityType + '\'' +
                ", prioritiesId='" + priorityTypeId + '\'' +
                '}';
    }
}
