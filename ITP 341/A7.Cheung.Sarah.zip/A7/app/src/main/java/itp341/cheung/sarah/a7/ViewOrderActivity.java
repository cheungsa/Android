package itp341.cheung.sarah.a7;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import itp341.cheung.sarah.a7.Model.Card;
import itp341.cheung.sarah.a7.Model.Ticket;


public class ViewOrderActivity extends AppCompatActivity {
    public static final String VERIFIED_VALUE = "itp341.cheung.sarah.a6.VERIFIED_VALUE";
    public static final String EDIT_AGAIN_VALUE = "itp341.cheung.sarah.a6.EDIT_AGAIN_VALUE";

    Card card_viewOrder;
    Ticket ticket_viewOrder;

    private TextView tripFromText;
    private TextView tripToText;
    private TextView ticketText;
    private TextView priorityText;
    private TextView cardNumText;
    private TextView cardNameText;
    private Button editTktBtn;
    private Button editCardBtn;
    private Button purchaseBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_orders);

        Intent intentTicket = getIntent();
        ticket_viewOrder = (Ticket)intentTicket.getExtras().getSerializable(MainActivity.TICKET_VALUE);
        card_viewOrder = (Card)intentTicket.getExtras().getSerializable(CardActivity.CARD_VALUE);

        tripFromText = (TextView) findViewById(R.id.text_trip_from_entry);
        tripToText = (TextView) findViewById(R.id.text_trip_to_entry);
        ticketText = (TextView) findViewById(R.id.text_trip_type_entry);
        priorityText = (TextView) findViewById(R.id.text_priority_type_entry);
        cardNumText = (TextView) findViewById(R.id.text_card_number_entry);
        cardNameText = (TextView) findViewById(R.id.text_card_name_entry);
        editTktBtn = (Button) findViewById(R.id.button_edit_ticket);
        editCardBtn = (Button) findViewById(R.id.button_edit_card);
        purchaseBtn = (Button) findViewById(R.id.button_purchase);

        if (card_viewOrder != null) {
            cardNameText.setText(card_viewOrder.getName());
            cardNumText.setText(card_viewOrder.getNumber());
        }
        if (ticket_viewOrder != null){
            priorityText.setText(ticket_viewOrder.getPriorityType());
            ticketText.setText(ticket_viewOrder.getTripType());
            tripToText.setText(ticket_viewOrder.getEndingLocation());
            tripFromText.setText(ticket_viewOrder.getStartingLocation());
        }

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String name = preferences.getString("Name", "");
        String number = preferences.getString("Number", "");
        if(!name.equals("")){
            cardNameText.setText(name);
            card_viewOrder.setName(name);
        }
        if(!number.equals("")){
            cardNumText.setText(number);
            card_viewOrder.setNumber(number);
        }

        editTktBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                i.putExtra(EDIT_AGAIN_VALUE, true);
                i.putExtra(CardActivity.CARD_VALUE, card_viewOrder);
                i.putExtra(MainActivity.TICKET_VALUE, ticket_viewOrder);
                setResult(3, i);
                finish();
            }
        });

        editCardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CardActivity.class);
                i.putExtra(CardActivity.CARD_VALUE, card_viewOrder);
                i.putExtra(MainActivity.TICKET_VALUE, ticket_viewOrder);
                i.putExtra(EDIT_AGAIN_VALUE, true);

                startActivityForResult(i, 4);
            }
        });

        purchaseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                i.putExtra(VERIFIED_VALUE, true);
                i.putExtra(CardActivity.CARD_VALUE, card_viewOrder);
                setResult(2, i);
                finish();
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 4){
            card_viewOrder = (Card)data.getExtras().getSerializable(CardActivity.CARD_VALUE);
            cardNumText.setText(card_viewOrder.getNumber());
            cardNameText.setText(card_viewOrder.getName());

            ticket_viewOrder = (Ticket) data.getExtras().getSerializable(MainActivity.TICKET_VALUE);
            tripFromText.setText(ticket_viewOrder.getStartingLocation());
            tripToText.setText(ticket_viewOrder.getEndingLocation());
            ticketText.setText(ticket_viewOrder.getTripType());
            priorityText.setText(ticket_viewOrder.getPriorityType());
        }
    }
}
