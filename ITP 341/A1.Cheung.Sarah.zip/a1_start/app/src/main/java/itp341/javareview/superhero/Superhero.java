/* EDIT THIS FILE */

package itp341.javareview.superhero;

import java.util.Random;

public class Superhero {
    private String name;
    private int healthPoints;
    private int attackValue;
    public static final int MAX_HEALTHPOINTS = 100; // - +
    public static final int MAX_ATTACKVALUE = 20;
    public static final int MIN_HEALTHPOINTS = 0;
    public static final int MIN_ATTACKVALUE = 5;

    public Superhero(String name) {
        this.name = name;
        healthPoints = MAX_HEALTHPOINTS;

        Random rand = new Random();
        attackValue = rand.nextInt(MAX_ATTACKVALUE - MIN_ATTACKVALUE + 1) + MIN_ATTACKVALUE;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }

    public void setAttackValue(int attackValue) {
        this.attackValue = attackValue;
    }

    public String getName() {
        return name;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    public int getAttackValue() {
        return attackValue;
    }

    public String getHeroStatus() {
        String status = "\nName: " + name +
                        "\nHealth Points: " + healthPoints +
                        "\nAttack Value: " + attackValue;
        return status;
    }

    public boolean isInjured() {
        if (healthPoints <= MIN_HEALTHPOINTS) {
            return true;
        }
        return false;
    }

    public void loseHealthPoints(int damage) {
        healthPoints -= damage;
    }
}




