/* EDIT THIS FILE */

package itp341.javareview.superhero;

public class HeroBattle {
    public String play() {
        Superhero p1 = new Superhero("Wolverine");
        Superhero p2 = new Superhero("Magneto");
        String gameLog = "HEROES" + p1.getHeroStatus() + p2.getHeroStatus() + "\n\nFIGHT!";
        int round = 1;

        while (!p1.isInjured() && !p2.isInjured()) {
            p1.setHealthPoints(p1.getHealthPoints() - p2.getAttackValue());
            p2.setHealthPoints(p2.getHealthPoints() - p1.getAttackValue());
            gameLog += "\n====== Round " + round +
                      " ======" + p1.getHeroStatus() + p2.getHeroStatus() + "\n";
            round++;
        }

        if (p1.isInjured() && p2.isInjured()) {
            gameLog += "\nThere was a tie!";
        }
        else if (p1.isInjured()) {
            gameLog += "\n" + p2.getName() + " won!";
        }
        else {
            gameLog += "\n" + p1.getName() + " won!";
        }
        return gameLog;
    }
}
