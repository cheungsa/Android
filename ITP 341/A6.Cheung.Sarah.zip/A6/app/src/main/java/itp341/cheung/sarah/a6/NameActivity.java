package itp341.cheung.sarah.a6;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;

public class NameActivity extends AppCompatActivity {
    public static final int REQUEST_CODE = 3;

    EditText editName;
    Button buttonSetChangesName;

    private String strName = "";
    private String strName_main = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);

        editName = (EditText)findViewById(R.id.edit_name);
        buttonSetChangesName = (Button)findViewById(R.id.button_set_changes_name);

        strName_main = getIntent().getStringExtra(MainActivity.NAME_VALUE);

        buttonSetChangesName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strName = editName.getText().toString();
                if (strName_main.equals(strName)) {
                    setResult(1,getIntent());
                    finish();
                }
                else {
                    setResult(0,getIntent());
                    finish();
                }
            }
        });

    }
}
