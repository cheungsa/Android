package itp341.cheung.sarah.a6;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class SizeActivity extends AppCompatActivity {
    public static final int REQUEST_CODE = 2;

    Button buttonSetChangesSize;
    Spinner spinnerSize;

    private String strSize = "";
    private String strSize_main = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_size);

        buttonSetChangesSize = (Button)findViewById(R.id.button_set_changes_size);
        spinnerSize = (Spinner)findViewById(R.id.spinner_size);

        strSize_main = getIntent().getStringExtra(MainActivity.SIZE_VALUE);

        buttonSetChangesSize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strSize = spinnerSize.getSelectedItem().toString();
                if (strSize_main.equals(strSize)){
                    setResult(1,getIntent());
                    finish();
                }
                else {
                    setResult(0,getIntent());
                    finish();
                }
            }
        });

    }
}
