package itp341.cheung.sarah.a6;

import android.support.v7.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Button;

public class ColorActivity extends AppCompatActivity {
    public static final int REQUEST_CODE = 1;

    TextView textR;
    TextView textG;
    TextView textB;
    TextView textPreview;
    SeekBar seekBarR;
    SeekBar seekBarG;
    SeekBar seekBarB;
    Button buttonSetChangesColor;

    private int rVal = 0;
    private int gVal = 0;
    private int bVal = 0;

    private int rVal_main = 0;
    private int gVal_main = 0;
    private int bVal_main = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);

        textR = (TextView)findViewById(R.id.text_r_val);
        textG = (TextView)findViewById(R.id.text_g_val);
        textB = (TextView)findViewById(R.id.text_b_val);
        textPreview = (TextView)findViewById(R.id.text_preview_color);

        seekBarR = (SeekBar)findViewById(R.id.seekbar_r);
        seekBarG = (SeekBar)findViewById(R.id.seekbar_g);
        seekBarB = (SeekBar)findViewById(R.id.seekbar_b);

        buttonSetChangesColor = (Button)findViewById(R.id.button_set_changes_color);

        rVal_main = getIntent().getIntExtra(MainActivity.RED_VALUE,0);
        gVal_main = getIntent().getIntExtra(MainActivity.GREEN_VALUE,0);
        bVal_main = getIntent().getIntExtra(MainActivity.BLUE_VALUE,0);

        seekBarR.setMax(255);
        seekBarG.setMax(255);
        seekBarB.setMax(255);

        seekBarR.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                rVal = i;
                textR.setText("R: " + Integer.toString(rVal));
                textPreview.setBackgroundColor(Color.rgb(rVal,gVal,bVal));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        seekBarG.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                textPreview.setBackgroundColor(Color.rgb(rVal,i,bVal));
                gVal = i;
                textG.setText("G: " + Integer.toString(gVal));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        seekBarB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                textPreview.setBackgroundColor(Color.rgb(rVal,gVal,i));
                bVal = i;
                textB.setText("B: " + Integer.toString(bVal));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        buttonSetChangesColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((rVal == rVal_main) && (gVal == gVal_main) && (bVal == bVal_main)){
                    setResult(1,getIntent());
                    finish();
                }
                else{
                    setResult(0,getIntent());
                    finish();
                }
            }
        });
    }
}
