package itp341.cheung.sarah.a6;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;
import android.content.Intent;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity {
    public static final String RED_VALUE = "itp341.cheung.sarah.a6.RED_VALUE";
    public static final String GREEN_VALUE = "itp341.cheung.sarah.a6.GREEN_VALUE";
    public static final String BLUE_VALUE = "itp341.cheung.sarah.a6.BLUE_VALUE";
    public static final String SIZE_VALUE = "itp341.cheung.sarah.a6.SIZE_VALUE";
    public static final String NAME_VALUE = "itp341.cheung.sarah.a6.NAME_VALUE";
    public static final String PET_VALUE = "itp341.cheung.sarah.a6.PET_VALUE";
    public static final String WIN_LOSE_VALUE = "itp341.cheung.sarah.a6.WIN_LOSE_VALUE";
    public static final String NUM_COMPLETE_PUZZLE = "itp341.cheung.sarah.a6.NUM_COMPLETE_PUZZLE";

    Button buttonDoor1;
    Button buttonDoor2;
    Button buttonDoor3;
    Button buttonDoor4;
    Button buttonSolve;
    Button buttonCheat;
    TextView textClue1;
    TextView textClue2;
    TextView textClue3;
    TextView textClue4;

    private int numPuzzleComplete = 0;
    private int correctRedVal = 255;
    private int correctGreenVal = 0;
    private int correctBlueVal = 0;
    private String correctSize = "small";
    private String correctName = "ladybug";
    private String correctPet = "dog";

    private String[] colors;
    private String[] sizes;
    private String[] names;
    private int colorIndex;
    private int sizeIndex;
    private int nameIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textClue1 = (TextView)findViewById(R.id.text_clue1);
        textClue2 = (TextView)findViewById(R.id.text_clue2);
        textClue3 = (TextView)findViewById(R.id.text_clue3);
        textClue4 = (TextView)findViewById(R.id.text_clue4);
        buttonDoor1 = (Button)findViewById(R.id.button_door1);
        buttonDoor2 = (Button)findViewById(R.id.button_door2);
        buttonDoor3 = (Button)findViewById(R.id.button_door3);
        buttonDoor4 = (Button)findViewById(R.id.button_door4);
        buttonSolve = (Button)findViewById(R.id.button_solve);
        buttonCheat = (Button) findViewById(R.id.button_cheat);

        randomize();
        setAnswers();

        String colorClue = textClue1.getText().toString();
        colorClue += colors[colorIndex];
        textClue1.setText(colorClue);
        //textClue1.setTextColor(Color.rgb(RValue, GValue, BValue));

        String sizeClue = textClue2.getText().toString();
        sizeClue += correctSize;
        textClue2.setText(sizeClue);
        //desirePuzzleView.setTextColor(Color.rgb(RValue, GValue, BValue));

        String nameClue = textClue3.getText().toString();
        nameClue += correctName;
        textClue3.setText(nameClue);
        //namePuzzleView.setTextColor(Color.rgb(RValue, GValue, BValue));

        //schoolPuzzleView.setTextColor(Color.rgb(RValue, GValue, BValue));

        buttonDoor1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ColorActivity.class);
                i.putExtra(RED_VALUE,correctRedVal);
                i.putExtra(GREEN_VALUE,correctGreenVal);
                i.putExtra(BLUE_VALUE,correctBlueVal);
                i.putExtra(NUM_COMPLETE_PUZZLE,numPuzzleComplete);
                startActivityForResult(i, ColorActivity.REQUEST_CODE);
            }
        });

        buttonDoor2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SizeActivity.class);
                i.putExtra(SIZE_VALUE,correctSize);
                i.putExtra(NUM_COMPLETE_PUZZLE,numPuzzleComplete);
                startActivityForResult(i, SizeActivity.REQUEST_CODE);
            }
        });

        buttonDoor3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, NameActivity.class);
                i.putExtra(NAME_VALUE, correctName);
                i.putExtra(NUM_COMPLETE_PUZZLE, numPuzzleComplete);
                startActivityForResult(i, NameActivity.REQUEST_CODE);
            }
        });

        buttonDoor4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, PetActivity.class);
                i.putExtra(PET_VALUE, correctPet);
                i.putExtra(NUM_COMPLETE_PUZZLE, numPuzzleComplete);
                startActivityForResult(i, PetActivity.REQUEST_CODE);
            }
        });

        buttonSolve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, WinLoseActivity.class);
                i.putExtra(WIN_LOSE_VALUE, numPuzzleComplete);
                startActivityForResult(i, WinLoseActivity.REQUEST_CODE);
            }
        });

        buttonCheat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String soln =   "R: " + correctRedVal +
                                "; G: " + correctGreenVal +
                                "; B: " + correctBlueVal +
                                "\nSize: " + correctSize +
                                "\nName: " + correctName +
                                "\nPet: " + correctPet;

                Toast.makeText(MainActivity.this, soln, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // if 1st activity (color puzzle) is solved, increment numPuzzleCompleted
        if (requestCode == 1 && resultCode == 1 && numPuzzleComplete < 1) {
            numPuzzleComplete++;
            textClue1.setTextColor(Color.GREEN);
        }

        // if 2nd activity (size puzzle) is solved, increment numPuzzleCompleted
        if (requestCode == 2 && resultCode == 1 && numPuzzleComplete < 2 && numPuzzleComplete > 0) {
            numPuzzleComplete++;
            textClue2.setTextColor(Color.GREEN);
        }

        // if 3rd activity (name puzzle) is solved, increment numPuzzleCompleted
        if (requestCode == 3 && resultCode == 1 && numPuzzleComplete < 3 && numPuzzleComplete > 1) {
            numPuzzleComplete++;
            textClue3.setTextColor(Color.GREEN);
        }

        // if 4th activity (pet puzzle) is solved, increment numPuzzleCompleted
        if (requestCode == 4 && resultCode == 1 && numPuzzleComplete < 4 && numPuzzleComplete > 2) {
            numPuzzleComplete++;
            textClue4.setTextColor(Color.GREEN);
        }

        // EC: Reset the puzzle when the user clicks back on the Win activity and completed puzzle
        if (requestCode == 5 && numPuzzleComplete == 4) {
            textClue1.setTextColor(Color.RED);
            textClue2.setTextColor(Color.RED);
            textClue3.setTextColor(Color.RED);
            textClue4.setTextColor(Color.RED);
            numPuzzleComplete = 0;
        }
    }

    private void setAnswers(){
        if (colors[colorIndex].equals(colors[0])){
            correctRedVal = 0;
            correctGreenVal = 0;
            correctBlueVal = 255;
        }
        else if(colors[colorIndex].equals(colors[1])){
            correctRedVal = 255;
            correctGreenVal = 0;
            correctBlueVal = 0;
        }
        else if(colors[colorIndex].equals(colors[2])){
            correctRedVal = 0;
            correctGreenVal = 255;
            correctBlueVal = 0;
        }
        else {
            correctRedVal = 255;
            correctGreenVal = 255;
            correctBlueVal = 255;
        }
        correctSize = sizes[sizeIndex];
        correctName = names[nameIndex];
    }

    private void randomize() {
        colors = getResources().getStringArray(R.array.array_colors);
        sizes = getResources().getStringArray(R.array.array_sizes);
        names = getResources().getStringArray(R.array.array_names);

        colorIndex = random(colors.length);
        sizeIndex = random(sizes.length);
        nameIndex = random(names.length);
    }

    private int random(int length) {
        Random rand = new Random();
        return rand.nextInt(length);
    }

}
