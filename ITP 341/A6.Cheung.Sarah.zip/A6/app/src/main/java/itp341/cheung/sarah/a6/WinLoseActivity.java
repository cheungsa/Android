package itp341.cheung.sarah.a6;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class WinLoseActivity extends AppCompatActivity {
    public static final int REQUEST_CODE = 5;

    TextView textWinOrLose;

    private int numPuzzlesCompleted = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win_lose);

        textWinOrLose = (TextView)findViewById(R.id.text_win_or_lose);

        numPuzzlesCompleted = getIntent().getIntExtra(MainActivity.WIN_LOSE_VALUE,0);
        if (numPuzzlesCompleted == 4) {
            textWinOrLose.setText(getText(R.string.win));
        }

    }
}