package itp341.cheung.sarah.a6;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class PetActivity extends AppCompatActivity {
    public static final int REQUEST_CODE = 4;

    Button buttonSetChangesPet;
    Button buttonHint;
    Spinner spinnerPet;

    private String strPet = "";
    private String strPet_main = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet);

        buttonSetChangesPet = (Button)findViewById(R.id.button_set_changes_pet);
        buttonHint = (Button)findViewById(R.id.button_hint);
        spinnerPet = (Spinner)findViewById(R.id.spinner_pet);

        strPet_main = getIntent().getStringExtra(MainActivity.PET_VALUE);

        buttonSetChangesPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strPet = spinnerPet.getSelectedItem().toString();
                if (strPet_main.equals(strPet)){
                    setResult(1,getIntent());
                    finish();
                }
                else {
                    setResult(0,getIntent());
                    finish();
                }
            }
        });

        buttonHint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PetActivity.this, R.string.str_hint, Toast.LENGTH_LONG).show();
            }
        });
    }
}
