package itp341.cheung.sarah.a5;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    // TAG
    private static final String TAG = MainActivity.class.getSimpleName();

    // variables for widgets
    private CheckBox checkTakeoutYes; //checkPepperoni;
                                      //checkPineapple;
                                     //private CheckBox checkTofu;
    private RadioGroup radioGroupPaymentType; //radioGroupSize;
    private SeekBar seekBarNumPercent; //seekBarNumPizzas;
    private TextView textNumPercentSeekBarProgress; //textNumPizzasSeekBarProgress;
    private Spinner spinnerSplitBill;   //spinnerSpecials;
    private TextView textCalculatedTip; //textOrderDisplay;
    private TextView textCalculatedTotal;
    private EditText editBillAmount;      //editName;
    private TextView textPerPerson;
    private TextView textPerPersonAmount;

    private boolean wantsTakeout = false;
    private String paymentType;     //size;
    private String splitBill = "";  //specials = "";   //load from XML string-array in onCreate
    private int numPercent = 0;     //numPizzas = 1;
    private String billAmount = ""; //name = "";
    private String perPersonAmount = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // get references to widgets
        textCalculatedTip = findViewById(R.id.text_calculated_tip);
        textCalculatedTotal = findViewById(R.id.text_calculated_total);
        checkTakeoutYes = findViewById(R.id.check_takeout_yes);
        radioGroupPaymentType = findViewById(R.id.radio_payment_type);
        textNumPercentSeekBarProgress = findViewById(R.id.text_num_percent);
        seekBarNumPercent = findViewById(R.id.seekbar_percent_tip);
        spinnerSplitBill = findViewById(R.id.spinner_split_bill);
        editBillAmount = findViewById(R.id.edit_bill_amount);
        textPerPerson = findViewById(R.id.text_per_person);
        textPerPersonAmount = findViewById(R.id.text_calculated_per_person);

        // hide Per Person text
        textPerPerson.setVisibility(View.GONE);
        textPerPersonAmount.setVisibility(View.GONE);

        // load default special by using first element of array
        splitBill = getResources().getStringArray(R.array.label_array_split_bill)[0];

        // create EditorActionListener
        editBillAmount.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                Log.d(TAG, "inside onEditorAction");

                billAmount = editBillAmount.getText().toString();

                displayBillAmountAdvanced();
                return false;
            }
        });

        // create checkbox listeners
        checkTakeoutYes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Log.d(TAG, "in onCheckedChanged for checkTakeoutYes");
                //update pepperoni variable
                wantsTakeout = b;
                displayBillAmountAdvanced();
            }
        });

        // create radiogroup listener
        radioGroupPaymentType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                Log.d(TAG, "in oncheckedchangedlistener for radio group");

                switch (checkedId) {
                    case R.id.radio_cash:
                        paymentType = getResources().getString(R.string.label_payment_type_cash);
                        break;
                    case R.id.radio_credit:
                        paymentType = getResources().getString(R.string.label_payment_type_credit);
                        break;
                    case R.id.radio_venmo:
                        paymentType = getResources().getString(R.string.label_payment_type_venmo);
                        break;
                    default:
                        Log.d(TAG, "onCheckChangedListener - invalid checkedId");
                }
                displayBillAmountAdvanced();


            }
        });


        // seekbar listener
        seekBarNumPercent.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Log.d(TAG, "in onProgressChanged for seekBar");
                numPercent = i;

                //prepare final output string (using string formatting)
                String numPercentOutput = getString(R.string.label_changed_num_percent, numPercent, "%");
                textNumPercentSeekBarProgress.setText(numPercentOutput);
                displayBillAmountAdvanced();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        // create spinner listener
        spinnerSplitBill.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v,
                                       int position, long id) {
                Log.d(TAG, "spinner onitemselected");
                splitBill = ((TextView) v).getText().toString();
                if (splitBill.contains("No")) {
                    textPerPerson.setVisibility(View.GONE);
                    textPerPersonAmount.setVisibility(View.GONE);
                    displayBillAmountAdvanced();
                }
                else {
                    textPerPerson.setVisibility(View.VISIBLE);
                    textPerPersonAmount.setVisibility(View.VISIBLE);
                    displayBillAmountAdvanced();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }

        });
    }

        //TODO generate "human-readable" description of pizza and write to textView
        @SuppressLint("StringFormatInvalid")
        public void displayBillAmountAdvanced() {
            Log.d(TAG, billAmount);
            String tipOutput = "";
            String totalOutput = "";
            String perPersonOutput = "";
            if (isBillValid() == true) {
                double toNumBillAmount = 0;
                try {
                    toNumBillAmount = Double.parseDouble(billAmount);
                } catch (NumberFormatException nfe) {
                    Log.d(TAG,"nfe: failed to convert bill amount from string to double\n");
                }
                double numTip = toNumBillAmount * numPercent / 100;
                double numTotal = toNumBillAmount + numTip;
                double numPerPerson = numTotal;

                if (splitBill != "No") {
                    if (splitBill.contains("2")) {
                        numPerPerson = numTotal / 2;
                    }
                    else if (splitBill.contains("3")) {
                        numPerPerson = numTotal / 3;
                    }
                    else if (splitBill.contains("4")) {
                        numPerPerson = numTotal / 4;
                    }
                }

                //prepare final output string (using string formatting)
                tipOutput = getString(R.string.label_final_calculated_tip, String.format("%.2f", numTip));
                totalOutput = getString(R.string.label_final_calculated_total, String.format("%.2f", numTotal));
                perPersonOutput = getString(R.string.label_final_calculated_total, String.format("%.2f", numPerPerson));
            }
            else {
                tipOutput = getString(R.string.label_calculated_tip);
                totalOutput = getString(R.string.label_calculated_total);
                perPersonOutput = getString(R.string.label_calculated_per_person);
            }
            textCalculatedTip.setText(tipOutput);
            textCalculatedTotal.setText(totalOutput);
            textPerPersonAmount.setText(perPersonOutput);
        }

    //determine what qualifies as a valid order
    public boolean isBillValid() {
        Log.d(TAG, billAmount);

        if (!editBillAmount.getText().toString().equals("")) {
            return true;
        }
        return false;
    }

}
