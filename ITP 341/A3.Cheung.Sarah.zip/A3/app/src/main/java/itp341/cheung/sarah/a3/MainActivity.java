package itp341.cheung.sarah.a3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    // step 1: create private member/instance variables
    private TextView textP1Score;
    private TextView textP2Score;
    private TextView textLog;
    private ImageView imageDice;
    private Button buttonRoll;
    private Button buttonHold;
    private Button buttonReset;
    private boolean isP1 = true;
    private boolean isCompMode = false;
    private int p1_score = 0; // - +
    private int p2_score = 0;
    private int turn_score = 0;

    private Random rand = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // step 2: get references to all our widgets
        textP1Score = findViewById(R.id.text_p1score);
        textP2Score = findViewById(R.id.text_p2score);
        textLog = findViewById(R.id.text_gamelog);
        imageDice = findViewById(R.id.image_dice);
        buttonRoll = findViewById(R.id.button_roll);
        buttonHold = findViewById(R.id.button_hold);
        buttonReset = findViewById(R.id.button_reset);

        buttonRoll.setOnClickListener(this);
        buttonHold.setOnClickListener(this);
        buttonReset.setOnClickListener(this);

        // step 3: set text and images from resources
        textP1Score.setText(getString(R.string.player_1_score, p1_score));
        textP2Score.setText(getString(R.string.player_2_score, p2_score));
        //textP1Score.setText(getResources().getString(R.string.player_1_score));
        //textP2Score.setText(getResources().getString(R.string.player_2_score));
        textLog.setText(getResources().getString(R.string.game_log_start));
        Picasso.get().load(R.drawable.blank_die).into(imageDice);

        // disable 'Hold' button
        buttonHold.setEnabled(false);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_roll:
                int num = rand.nextInt(6) + 1;
                switch (num) {
                    case 1:
                        if (isP1) {
                            Picasso.get().load(R.drawable.blue_die_1).into(imageDice);
                        }
                        else {
                            Picasso.get().load(R.drawable.red_die_1).into(imageDice);
                        }
                        Toast.makeText(getApplicationContext(),
                                getResources().getString(R.string.dice_1),
                                Toast.LENGTH_SHORT).show();

                        isP1 = !isP1;
                        turn_score = 0;
                        if (buttonHold.isEnabled()) {
                            if ((isP1 && turn_score == 0) || (!isP1 && turn_score == 0)) {
                                buttonHold.setEnabled(false);
                            }
                        }
                        Picasso.get().load(R.drawable.blank_die).into(imageDice);
                        break;
                    case 2:
                        if (isP1) {
                            Picasso.get().load(R.drawable.blue_die_2).into(imageDice);
                        }
                        else {
                            Picasso.get().load(R.drawable.red_die_2).into(imageDice);
                        }
                        turn_score += 2;
                        break;
                    case 3:
                        if (isP1) {
                            Picasso.get().load(R.drawable.blue_die_3).into(imageDice);
                        }
                        else {
                            Picasso.get().load(R.drawable.red_die_3).into(imageDice);
                        }
                        turn_score += 3;
                        break;
                    case 4:
                        if (isP1) {
                            Picasso.get().load(R.drawable.blue_die_4).into(imageDice);
                        }
                        else {
                            Picasso.get().load(R.drawable.red_die_4).into(imageDice);
                        }
                        turn_score += 4;
                        break;
                    case 5:
                        if (isP1) {
                            Picasso.get().load(R.drawable.blue_die_5).into(imageDice);
                        }
                        else {
                            Picasso.get().load(R.drawable.red_die_5).into(imageDice);
                        }
                        turn_score += 5;
                        break;
                    case 6:
                        if (isP1) {
                            Picasso.get().load(R.drawable.blue_die_6).into(imageDice);
                        }
                        else {
                            Picasso.get().load(R.drawable.red_die_6).into(imageDice);
                        }
                        turn_score += 6;
                        break;
                    default:
                        break;
                }
                if (!buttonHold.isEnabled()) {
                    if ((isP1 && turn_score > 0) || (!isP1 && turn_score > 0)) {
                        buttonHold.setEnabled(true);
                    }
                }
                if (isP1) {
                    textLog.setText(getString(R.string.game_log_p1_turn_score, turn_score));
                }
                else {
                    textLog.setText(getString(R.string.game_log_p2_turn_score, turn_score));
                    //textLog.setText(getResources().getString(R.string.game_log_p2_turn_score) + turn_score);
                }
                break;
            case R.id.button_hold:
                if (isP1) {
                    p1_score += turn_score;
                    textP1Score.setText(getString(R.string.player_1_score, p1_score));
                    //textP1Score.setText(p1_score);
                }
                else {
                    p2_score += turn_score;
                    textP2Score.setText(getString(R.string.player_2_score, p2_score));
                    //textP2Score.setText(p2_score);
                }
                if (p1_score >= 100) {
                    textLog.setText(getResources().getString(R.string.player_1_win));
                    turn_score = 0;
                    buttonHold.setEnabled(false);
                    buttonRoll.setEnabled(false);
                    break;
                }
                else if (p2_score >= 100) {
                    textLog.setText(getResources().getString(R.string.player_2_win));
                    buttonHold.setEnabled(false);
                    buttonRoll.setEnabled(false);
                    break;
                }
                isP1 = !isP1;
                turn_score = 0;
                if (isP1) {
                    textLog.setText(getResources().getString(R.string.game_log_p1_turn));
                    buttonHold.setEnabled(false);
                }
                else {
                    textLog.setText(getResources().getString(R.string.game_log_p2_turn));
                    buttonHold.setEnabled(false);
                }
                Picasso.get().load(R.drawable.blank_die).into(imageDice);
                if (buttonHold.isEnabled()) {
                    if ((isP1 && turn_score == 0) || (!isP1 && turn_score == 0)) {
                        buttonHold.setEnabled(false);
                    }
                }
                break;
            case R.id.button_reset:
                if (!buttonRoll.isEnabled()) {
                    buttonRoll.setEnabled(true);
                }
                isP1 = true;
                turn_score = 0;
                p1_score = 0;
                p2_score = 0;
                buttonHold.setEnabled(false);
                Picasso.get().load(R.drawable.blank_die).into(imageDice);
                textLog.setText(getResources().getString(R.string.game_log_start));
                textP1Score.setText(getString(R.string.player_1_score, p1_score));
                textP2Score.setText(getString(R.string.player_2_score, p2_score));
                break;
            default:
                break;
        }
    }
}
