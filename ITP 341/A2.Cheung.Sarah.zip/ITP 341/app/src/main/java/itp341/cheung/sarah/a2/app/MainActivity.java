package itp341.cheung.sarah.a2.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    // step 1: create private member/instance variables
    private TextView textPet;
    private Button buttonDog;
    private Button buttonCat;
    private int dog = 0;
    private int cat = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // step 2: get references to all our widgets
        textPet = findViewById(R.id.pet);
        buttonDog = findViewById(R.id.button_dog);
        buttonCat = findViewById(R.id.button_cat);
        buttonDog.setOnClickListener(this);
        buttonCat.setOnClickListener(this);

        // step 3: set question text from string resources
        textPet.setText(getResources().getString(R.string.text_choice));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_dog:
                dog++;
                Toast.makeText(getApplicationContext(),
                        getResources().getString(R.string.text_dog) + dog,
                        Toast.LENGTH_LONG).show();
                break;
            case R.id.button_cat:
                cat++;
                Toast.makeText(getApplicationContext(),
                        getResources().getString(R.string.text_cat) + cat,
                        Toast.LENGTH_LONG).show();
                break;
            default:
                break;
        }
    }
}
