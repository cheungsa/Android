package itp341.cheung.sarah.finalprojectapp.Model;

import java.io.Serializable;

public class Player implements Serializable {
    private String name;
    private String id;
    private int totalRice;
    private int gamesPlayed;
    private int wins;
    private int losses;
    private int draws;

    public Player() {
        this.name = "";
        this.totalRice = 0;
        this.gamesPlayed = 0;
        this.wins = 0;
        this.losses = 0;
        this.draws = 0;
        this.id = "";
    }

    public Player(String name, int totalRice, int gamesPlayed, int wins, int losses, int draws, String id) {
        this.name = name;
        this.totalRice = totalRice;
        this.gamesPlayed = gamesPlayed;
        this.wins = wins;
        this.losses = losses;
        this.draws = draws;
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTotalRice(int totalRice) {
        this.totalRice = totalRice;
    }

    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public void setLosses(int losses) {
        this.losses = losses;
    }

    public void setDraws(int draws) {
        this.draws = draws;
    }

    public String getName() {
        return name;
    }

    public int getTotalRice() {
        return totalRice;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }

    public int getDraws() {
        return draws;
    }

    public String getId() { return id; }

    public void setId(String id) { this.id = id; }

    public String displayInfo(String tag) {
        return "~~~~~" + tag + "~~~~~" +
                "\nName: " + name +
                "\nRice: " + name +
                "\nGames: " + name +
                "\nWins: " + name +
                "\nLosses: " + name +
                "\nDraws: " + draws +
                "\nId: " + id +
                "\n~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    }
}