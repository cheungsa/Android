package itp341.cheung.sarah.finalprojectapp.Model;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import itp341.cheung.sarah.finalprojectapp.TicTacToeActivity;

public class BoardView extends View {

    private static final int LINE_SIZE = 6;
    private static final int TILE_SPACE = 21;
    private static final int TILE_WIDTH = 14;

    private TicTacToeActivity act;
    private Board board;
    private Paint gridPaint, oPaint, xPaint;

    private int width, height, tileWidth, tileHeight;

    public BoardView(Context context) {
        super(context);
    }

    public BoardView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        gridPaint = new Paint();

        //set o/x font
        oPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        oPaint.setStrokeWidth(TILE_WIDTH);
        oPaint.setStyle(Paint.Style.STROKE);
        oPaint.setColor(Color.BLUE);

        xPaint = new Paint(oPaint);
        xPaint.setColor(Color.RED);
    }

    public void setBoard(Board b) {
        board = b;
    }

    public void setTicTacToeActivity(TicTacToeActivity a) {
        act = a;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        width = View.MeasureSpec.getSize(widthMeasureSpec);
        tileWidth = (width - LINE_SIZE) / 3;

        height = View.MeasureSpec.getSize(heightMeasureSpec);
        tileHeight = (height - LINE_SIZE) / 3;

        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        drawGrid(canvas);
        drawBoard(canvas);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (!board.isGameOver()) {
                int x = (int) (event.getX() / tileWidth);
                int y = (int) (event.getY() / tileHeight);
                String win = board.play(x, y);
                invalidate();

                if (win != " ") {
                    act.gameEnded(win);
                }
                else {
                    // computer's turn
                    win = board.cpu();
                    invalidate();

                    if (win != " ") {
                        act.gameEnded(win);
                    }
                }
            }
        }

        return super.onTouchEvent(event);
    }

    private void drawBoard(Canvas canvas) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                drawTile(canvas, i, j, board.getTile(i, j));
            }
        }
    }

    private void drawGrid(Canvas canvas) {
        for (int i = 0; i < 2; i++) {
            float rightH = width;
            float leftH = 0;
            float topH = tileHeight * (1 + i);
            float bottomH = topH + LINE_SIZE;

            float bottomV = height;
            float topV = 0;
            float leftV = tileWidth * (1 + i);
            float rightV = leftV + LINE_SIZE;

            canvas.drawRect(leftH, topH, rightH, bottomH, gridPaint);
            canvas.drawRect(leftV, topV, rightV, bottomV, gridPaint);
        }
    }

    private void drawTile(Canvas canvas, int x, int y, String s) {
        if (s == "X") {
            float startX = (tileWidth * x) + TILE_SPACE;
            float startY = (tileHeight * y) + TILE_SPACE;
            float endX = startX + tileWidth - TILE_SPACE * 2;
            float endY = startY + tileHeight - TILE_SPACE;

            canvas.drawLine(startX, startY, endX, endY, xPaint);

            float startX2 = (tileWidth * (x + 1)) - TILE_SPACE;
            float startY2 = (tileHeight * y) + TILE_SPACE;
            float endX2 = startX2 - tileWidth + TILE_SPACE * 2;
            float endY2 = startY2 + tileHeight - TILE_SPACE;

            canvas.drawLine(startX2, startY2, endX2, endY2, xPaint);

            /*
            float startX = TILE_SPACE + (2 * tileWidth);
            float endX = (tileWidth + startX) - (2 * TILE_SPACE);
            float startY = TILE_SPACE + (y * tileHeight);
            float endY = startY - TILE_SPACE + tileHeight;

            canvas.drawLine(startX, startY, endX, endY, xPaint);

            float startX2 = ((x + 1) * tileWidth) - TILE_SPACE;
            float endX2 = (2 * TILE_SPACE) + startX2 - tileWidth;
            float startY2 = TILE_SPACE + (y * tileHeight);
            float endY2 = startY2 - TILE_SPACE + tileHeight;

            canvas.drawLine(startX2, startY2, endX2, endY2, xPaint);
            */
        }
        else if (s == "O") {
            float cy = tileHeight / 2 + (y * tileHeight);
            float cx = tileWidth / 2 + (x * tileWidth);
            float radius = (Math.min(tileHeight, tileWidth) / 2) - (2 * TILE_SPACE);

            canvas.drawCircle(cx, cy, radius, oPaint);
        }
    }

}