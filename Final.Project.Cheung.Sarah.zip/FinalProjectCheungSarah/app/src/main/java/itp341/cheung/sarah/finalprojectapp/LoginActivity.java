package itp341.cheung.sarah.finalprojectapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import itp341.cheung.sarah.finalprojectapp.Model.Player;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = LoginActivity.class.getSimpleName();
    public static final int RC_SIGN_IN = 1;
    public static final String EXTRA_PLAYER_LOGIN = "com.itp341.cheung.sarah.finalprojectapp.playerLogin";
    private FirebaseAuth firebaseAuth;
    private FirebaseUser user = null;
    private FirebaseDatabase database = null;
    private Player currPlayer = null;
    private Player intentPlayer = null;
    private DatabaseReference dr;
    private DatabaseReference drUser;

    EditText editEmail;
    EditText editPassword;
    Button buttonLogin;
    Button buttonBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // OAuth 2.0 Client ID: 843647173793-6l65sn17sa7b181lsks3qkbphnbjm9kd.apps.googleusercontent.com
        firebaseAuth = FirebaseAuth.getInstance();

        editEmail = (EditText) findViewById(R.id.edit_email);
        editPassword = (EditText) findViewById(R.id.edit_password);
        buttonLogin = (Button) findViewById(R.id.button_login_complete);
        buttonBack = (Button) findViewById(R.id.button_back);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailString = editEmail.getText().toString();
                String passwordString = editPassword.getText().toString();
                registerUser(emailString, passwordString);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivityForResult(i, 3);
            }
        });
    }

    private void registerUser(String email, String password) {
        String emailString = email;
        String passwordString = password;

        if (TextUtils.isEmpty(emailString)) {
            Toast.makeText(this, "Please enter email", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(passwordString)) {
            Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
        }

        firebaseAuth.signInWithEmailAndPassword(emailString, passwordString)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {
                            user = firebaseAuth.getCurrentUser();
                            if (user != null) {
                                Log.d("TAG", "firebaseAuth: user is NOT null!");
                                // get database
                                database = FirebaseDatabase.getInstance();
                                dr = database.getReference();
                                drUser = dr.child(user.getUid());

                                drUser.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        Log.d(TAG, "Login successful!");
                                        currPlayer = (Player) dataSnapshot.getValue(Player.class);
                                        Intent i = new Intent(getApplicationContext(), ProfileActivity.class);
                                        i.putExtra(EXTRA_PLAYER_LOGIN, currPlayer);
                                        //startActivity(i);

                                        startActivityForResult(i, 3);
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });
                            }

                            Intent i = new Intent(getApplicationContext(), ProfileActivity.class);
                            //startActivity(i);

                            startActivityForResult(i, 30);
                            Log.d(TAG, "Launching finish() but shouldn't...");
                            //finish();
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "You entered invalid information! Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }

    private void savePreferences(String name){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("Name", name);
        editor.apply();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10) {
            Log.d(TAG, "OnActivityResult from MainActivity");
        }
        else {
            Log.d(TAG, "OnActivityResult with requestCode " + requestCode + " and resultCode " + resultCode);
        }
    }
}
