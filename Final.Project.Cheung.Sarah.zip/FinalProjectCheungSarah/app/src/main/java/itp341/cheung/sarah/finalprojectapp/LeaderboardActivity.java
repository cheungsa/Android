package itp341.cheung.sarah.finalprojectapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import itp341.cheung.sarah.finalprojectapp.Model.Comment;
import itp341.cheung.sarah.finalprojectapp.Model.CommentSingleton;
import itp341.cheung.sarah.finalprojectapp.Model.Player;
import itp341.cheung.sarah.finalprojectapp.Model.PlayerSingleton;

public class LeaderboardActivity extends AppCompatActivity {
    private static final String TAG = LeaderboardActivity.class.getSimpleName();
    public static final String EXTRA_PLAYER_LIST = "itp341.cheung.sarah.finalprojectapp.Model.Player";
    //public static final String EXTRA_PLAYER_LIST = "com.itp341.cheung.sarah.player";

    private FirebaseDatabase database = null;
    private DatabaseReference dr = null;

    EditText editComment;
    Button buttonComment;
    Button buttonBack;
    ListView listPlayers;
    ListView listComments;

    //int movieIndex;

    AdapterPlayer adpt;
    AdapterComment adptC;
    Player currPlayer = null;
    ArrayList<Comment> comments;
    ArrayList<Player> players = new ArrayList<Player>();
    ArrayList<Player> orderedPlayers = new ArrayList<Player>();
    //Player currPlayer = new Player();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        // get database
        database = FirebaseDatabase.getInstance();
        dr = database.getReference();

        editComment = (EditText) findViewById(R.id.edit_comment);
        buttonComment = (Button) findViewById(R.id.button_comment);
        buttonBack = (Button) findViewById(R.id.button_back_leaderboard);
        //listPlayers =(ListView) findViewById(R.id.list_leaderboard);
        //listPlayers =(ListView) findViewById(R.id.list_comment);
        listComments =(ListView) findViewById(R.id.list_comment);

        comments = CommentSingleton.getSingleton().getComments();
        adptC = new LeaderboardActivity.AdapterComment(this, R.layout.layout_list_comments, comments);
        listComments.setAdapter(adptC);

        //adpt = new DetailActivity.AdapterComment(this, R.layout.layout_list_comment, MovieSingleton.getSingleton().getMovie(movieIndex).getComments());
        //listPlayers.setAdapter(adpt);
        //adpt = new AdapterPlayer(this, R.layout.layout_list_leaderboard, PlayerSingleton.getSingleton().getPlayers());

        buttonComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Comment comment = new Comment(editComment.getText().toString());
                CommentSingleton.getSingleton().addComment(comment);
                Log.d(TAG, "added comment: " + comment.getComment());
                editComment.getText().clear();
                adptC.notifyDataSetChanged();
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ProfileActivity.class);
                setResult(5, i);
                finish();
                //startActivityForResult(i, 5);
            }
        });

        dr.orderByChild("totalRice").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d(TAG, "In onDataChange()");
                for(DataSnapshot data: dataSnapshot.getChildren()){
//                    Log.d(TAG, "class from dataSnapshot is " + data.getValue(Player.class).getClass().getSimpleName());

                    /*
                    Player player = (Player) data.getValue(Player.class);
                    Log.d(TAG, "Current player " + player.getName() + " has " + player.getTotalRice() + " rice");
                    players.add(player);
                    if (players.size() == 1)
                    {
                        //adpt = new AdapterPlayer(getApplicationContext(), R.layout.layout_list_leaderboard, PlayerSingleton.getSingleton().getPlayers());
                        adpt = new AdapterPlayer(getApplicationContext(), R.layout.layout_list_leaderboard, players);
                        listPlayers.setAdapter(adpt);
                    }
                    else if(players.size() > 1)
                    {
                        adpt.notifyDataSetChanged();
                    }
                    //with tempName you can access their usernames and you will only get the usernames with session 2011, so you can directly populate your listView from here and use it
                    */
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private class AdapterPlayer extends ArrayAdapter<Player> {
        public AdapterPlayer(Context context, int resource, ArrayList<Player> players) {
            super(context, resource, players);
        }

        @Override
        public View getView(int pos, View v, ViewGroup vg) {

            if (v == null) {
                v = LayoutInflater.from(getContext()).inflate(R.layout.layout_list_leaderboard, vg, false);
            }
            /*
            Player player = getItem(pos);
            ImageView imagePlayer = (ImageView) findViewById(R.id.image_player);
            TextView textName_Player = (TextView) findViewById(R.id.text_profile_username_leaderboard);
            TextView textTotalRice_Player = (TextView) findViewById(R.id.text_total_rice_donated_count_leaderboard);
            TextView textGamesPlayed_Player = (TextView) findViewById(R.id.text_games_played_count_leaderboard);

            if (player == null) {
                Log.e(TAG, "null player in getView!");
                return v;
            }
            if (player.getName() == null || player.getName().isEmpty()) {
                //textName_Player.setText(R.string.profile_name);
            }
            else {
                textName_Player.setText(String.valueOf(player.getName()));
            }

            textGamesPlayed_Player.setText(String.valueOf(player.getTotalRice()));
            textTotalRice_Player.setText(String.valueOf(player.getGamesPlayed()));
*/
            return v;
        }
    }

    private class AdapterComment extends ArrayAdapter<Comment> {
        public AdapterComment(Context context, int resource, ArrayList<Comment> comments) {
            super(context, resource, comments);
        }

        @Override
        public View getView(int pos, View v, ViewGroup vg) {
            Log.d(TAG, "in getView");
            if (v == null) {
                v = LayoutInflater.from(getContext()).inflate(R.layout.layout_list_comments, vg, false);
            }
            TextView textComment = v.findViewById(R.id.text_comment);

            Comment comm = getItem(pos);
            textComment.setText(comm.getComment());
            Log.d(TAG, "viewing comment: " + comm.getComment());
            return v;
        }

        @Override
        public int getCount() {
            return comments.size();
        }

        @Override
        public Comment getItem(int position)
        {
            return comments.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }
    }
}
