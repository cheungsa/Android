package itp341.cheung.sarah.finalprojectapp.Model;

import android.content.Context;
import android.util.Log;
import java.util.ArrayList;

public class PlayerSingleton {
    private static PlayerSingleton singleton;
    private ArrayList<Player> players; // data source
    private Context context; // need the context (android-specific)

    // private singleton constructor
    private PlayerSingleton() {
        players = new ArrayList<Player>();
    }

    // singleton get method
    public static PlayerSingleton getSingleton() {
        if (singleton == null) {
            singleton = new PlayerSingleton();
        }
        return singleton;
    }

    public int getNumPlayers() {
        return players.size();
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public void setPlayers(ArrayList<Player> players) { this.players = players; }

    public Player getPlayer(int index) {
        if (index < 0 || index >= players.size()) {
            Log.d("ERROR", "getPlayer: index out of bounds");
            return null;
        }
        return players.get(index);
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void removePlayer(Player player) {
        players.remove(player);
    }

}
