package itp341.cheung.sarah.finalprojectapp.Model;

import java.util.Random;

public class Board {

    private static final Random RANDOM = new Random();
    private String[] tiles;
    private String currPlayer;
    private boolean isGameOver;

    public Board() {
        tiles = new String[9];
        newGame();
    }

    public boolean isGameOver() {
        return isGameOver;
    }

    public String play(int x, int y) {
        if (!isGameOver) {
            if (tiles[x + 3 * y ] == " ") {
                tiles[x + 3 * y] = currPlayer;
                switchPlayer();
            }
        }
        return checkEnd();
    }

    public void switchPlayer() {
        if (currPlayer == "X") {
            currPlayer = "O";
        }
        else {
            currPlayer = "X";
        }
    }

    public String getTile(int x, int y) {
        return tiles[3 * y + x];
    }

    public void newGame() {
        for (int i = 0; i  < tiles.length; i++) {
            tiles[i] = " ";
        }

        isGameOver = false;
        currPlayer = "O";
    }

    public String checkEnd() {
        for (int i = 0; i < 3; i++) {
            if (getTile(i, 0) != " ") {
                if (getTile(i, 1) == getTile(i, 0)) {
                    if (getTile(i, 2) == getTile(i, 1)) {
                        isGameOver = true;
                        return getTile(i, 0);
                    }
                }
            }
            if (getTile(0, i) != " ") {
                if (getTile(2, i) == getTile(1, i)) {
                    if (getTile(1, i) == getTile(0, i)) {
                        isGameOver = true;
                        return getTile(0, i);
                    }
                }
            }
        }
        if (getTile(0, 0) != " ") {
            if (getTile(2, 2) == getTile(1, 1)) {
                if (getTile(1, 1) == getTile(0, 0)) {
                    isGameOver = true;
                    return getTile(0, 0);
                }
            }
        }

        if (getTile(2, 0) != " ") {
            if (getTile(1, 1) == getTile(0, 2)) {
                if (getTile(2, 0) == getTile(1, 1)) {
                    isGameOver = true;
                    return getTile(2, 0);
                }
            }
        }

        for (int i = 0; i < 9; i++) {
            if (tiles[i] == " ")
                return " ";
        }

        return "D";
    }

    public String cpu() {
        if (isGameOver) {
            return checkEnd();
        }
        int position = -1;
        do {
            position = RANDOM.nextInt(9);
        } while (tiles[position] != " ");

        tiles[position] = currPlayer;
        switchPlayer();

        return checkEnd();
    }

}
