package itp341.cheung.sarah.finalprojectapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import itp341.cheung.sarah.finalprojectapp.Model.Board;
import itp341.cheung.sarah.finalprojectapp.Model.Player;
import itp341.cheung.sarah.finalprojectapp.Model.PlayerSingleton;

public class ProfileActivity extends AppCompatActivity {
    private static final String TAG = ProfileActivity.class.getSimpleName();
    public static final String EXTRA_PLAYER_PROFILE = "com.itp341.cheung.sarah.finalprojectapp.playerProfile";
    public static final String EXTRA_PLAYER_WINS = "com.itp341.cheung.sarah.finalprojectapp.wins";
    public static final String EXTRA_PLAYER_LOSSES = "com.itp341.cheung.sarah.finalprojectapp.losses";
    public static final String EXTRA_PLAYER_DRAWS = "com.itp341.cheung.sarah.finalprojectapp.draws";
    public static final String EXTRA_PLAYER_GAMES = "com.itp341.cheung.sarah.finalprojectapp.games";
    public static final String EXTRA_PLAYER_RICE = "com.itp341.cheung.sarah.finalprojectapp.rice";
    public static final int RC_SIGN_IN = 1;

    private FirebaseUser user = null;
    private FirebaseDatabase database = null;
    private Player currPlayer = null;
    private Player intentPlayer = null;
    private DatabaseReference dr;
    private DatabaseReference drUser;
    private AdView mAdView;

    ImageView imageProfile;
    TextView textProfileName;
    TextView textTotalRiceDonated;
    TextView textGamesPlayed;
    TextView textWins;
    TextView textLosses;
    TextView textDraws;
    Button buttonSignOut;
    Button buttonTicTacToe;
    Button buttonLeaderboard;

    Intent intentMain;
    Intent intentLogin;
    Intent intentGeneral;

    private String emailStr = "";
    private String nameStr = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        imageProfile = (ImageView) findViewById(R.id.image_profile);
        textProfileName = (TextView) findViewById(R.id.text_profile_username);
        textTotalRiceDonated = (TextView) findViewById(R.id.text_total_rice_donated_count);
        textGamesPlayed = (TextView) findViewById(R.id.text_games_played_count);
        textWins = (TextView) findViewById(R.id.text_wins_count);
        textLosses = (TextView) findViewById(R.id.text_losses_count);
        textDraws = (TextView) findViewById(R.id.text_draws_count);
        buttonTicTacToe = (Button) findViewById(R.id.button_tic_tac_rice);
        buttonLeaderboard = (Button) findViewById(R.id.button_leaderboard);
        buttonSignOut = (Button) findViewById(R.id.button_sign_out);

        intentGeneral = getIntent();

        // Loading ads
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        // if user is logged in
        user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            Log.d(TAG, "OnCreate: user is NOT null!");
            // get database
            database = FirebaseDatabase.getInstance();
            // FB database path must not contain '.'
            //email = user.getEmail().substring(0, user.getEmail().indexOf('.'));
            dr = database.getReference();
            drUser = dr.child(user.getUid());
            //dr.child("users").child(email).push();

            //setPlayerData(user);
            retrievePreferences();
            setIntentPlayerData();
            textProfileName.setText(user.getDisplayName());
            Log.d(TAG, "OnCreate: user is " + user.getDisplayName());
        }
        else {
            Log.d(TAG, "OnCreate: user is null!");
        }

        // set underline for profile text
        Log.d(TAG, "Underlining profile name");
        SpannableString content = new SpannableString(textProfileName.getText());
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        textProfileName.setText(content);
        Log.d(TAG, "Successfully underlined profile name");

        dr.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                currPlayer = (Player) dataSnapshot.getValue(Player.class);
                if (currPlayer == null) {
                    currPlayer = new Player();
                    currPlayer.setName(user.getDisplayName());
                    Log.d(TAG, "User database drUser changed for null player");
                }
                else if (currPlayer.getName().isEmpty()) {
                    Log.d(TAG, "User database drUser changed for player with empty name -> change to intentPlayer");
                    Intent i = getIntent();

                    // extract info from login
                    intentPlayer = (Player) i.getSerializableExtra((MainActivity.EXTRA_PLAYER_MAIN));
                    if (intentPlayer != null) {
                        currPlayer = intentPlayer;
                    }
                    // extract info from tictactoe
                    else {
                        Log.d(TAG, "User database drUser changed for null player -> intentPlayer is null");
                        retrievePreferences();
                    }
                }
                else {
                    Log.d(TAG, "User database drUser changed for " + currPlayer.getName());
                }
                textTotalRiceDonated.setText(String.valueOf(currPlayer.getTotalRice()));
                textGamesPlayed.setText(String.valueOf(currPlayer.getGamesPlayed()));
                textWins.setText(String.valueOf(currPlayer.getWins()));
                textLosses.setText(String.valueOf(currPlayer.getLosses()));
                textDraws.setText(String.valueOf(currPlayer.getDraws()));

                Log.d(TAG, "OnActivityResult: onDataChange successful!");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        buttonTicTacToe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), TicTacToeActivity.class);
                if (currPlayer == null) {
                    currPlayer = new Player();
                }

                //retrievePreferences();
                savePreferences();
                i.putExtra(EXTRA_PLAYER_PROFILE, currPlayer);
                /*
                i.putExtra(EXTRA_PLAYER_RICE, currPlayer.getTotalRice());
                i.putExtra(EXTRA_PLAYER_GAMES, currPlayer.getGamesPlayed());
                i.putExtra(EXTRA_PLAYER_WINS, currPlayer.getWins());
                i.putExtra(EXTRA_PLAYER_LOSSES, currPlayer.getLosses());
                i.putExtra(EXTRA_PLAYER_DRAWS, currPlayer.getDraws());
                */
                startActivityForResult(i, 1);
            }
        });

        buttonLeaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), LeaderboardActivity.class);
                savePreferences();
                startActivityForResult(i, 2);
            }
        });

        buttonSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivityForResult(i, 3);
            }
        });

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
                Log.d(TAG, "Ad successfully loaded!");
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
                Log.d(TAG, "Ad failed to load!");
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });
    }

    private void setPlayerData(FirebaseUser user) {
        // Name, email address, and profile photo Url
        String name = user.getDisplayName();
        String email = user.getEmail();
        Uri photoUrl = user.getPhotoUrl();

        // Check if user's email is verified
        boolean emailVerified = user.isEmailVerified();

        // The user's ID, unique to the Firebase project. Do NOT use this value to
        // authenticate with your backend server, if you have one. Use
        // FirebaseUser.getIdToken() instead.
        String uid = user.getUid();

        if (name == null) {
            Intent i = getIntent();
            intentPlayer = (Player) i.getSerializableExtra((MainActivity.EXTRA_PLAYER_MAIN));
            textProfileName.setText(intentPlayer.getName());
            nameStr = intentPlayer.getName();

            // set underline for profile text
            Log.d(TAG, "Underlining profile name in setPlayerData using intent: " + name);
            SpannableString content = new SpannableString(textProfileName.getText());
            content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
            textProfileName.setText(content);
            Log.d(TAG, "Successfully underlined profile name");
        }
        else if (name.isEmpty()) {
            Intent i = getIntent();
            nameStr = i.getStringExtra(MainActivity.EXTRA_PLAYER_MAIN);
            textProfileName.setText(nameStr);
            name = nameStr;

            // set underline for profile text
            Log.d(TAG, "Underlining profile name in setPlayerData using intent: " + name);
            SpannableString content = new SpannableString(textProfileName.getText());
            content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
            textProfileName.setText(content);
            Log.d(TAG, "Successfully underlined profile name");
        }
        else if (name != null && !name.isEmpty()) {
            textProfileName.setText(name);

            // set underline for profile text
            Log.d(TAG, "Underlining profile name in setPlayerData: " + name);
            SpannableString content = new SpannableString(textProfileName.getText());
            content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
            textProfileName.setText(content);
            Log.d(TAG, "Successfully underlined profile name");
        }
    }

    private void savePreferences(){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("Id", user.getUid());
        editor.putString("Name", textProfileName.getText().toString());
        editor.putInt("Rice", Integer.parseInt(textTotalRiceDonated.getText().toString()));
        editor.putInt("Games", Integer.parseInt(textGamesPlayed.getText().toString()));
        editor.putInt("Wins", Integer.parseInt(textWins.getText().toString()));
        editor.putInt("Losses", Integer.parseInt(textLosses.getText().toString()));
        editor.putInt("Draws", Integer.parseInt(textDraws.getText().toString()));
        editor.apply();
    }

    private void retrievePreferences() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String name = preferences.getString("Name", "");
        String id = preferences.getString("Id", "");
        int totalRice = preferences.getInt("Rice", 0);
        int gamesPlayed = preferences.getInt("Games", 0);
        int wins = preferences.getInt("Wins", 0);
        int losses = preferences.getInt("Losses", 0);
        int draws = preferences.getInt("Draws", 0);

        //textProfileName.setText(name);
        textTotalRiceDonated.setText(String.valueOf(totalRice));
        textGamesPlayed.setText(String.valueOf(gamesPlayed));
        textWins.setText(String.valueOf(wins));
        textLosses.setText(String.valueOf(losses));
        textDraws.setText(String.valueOf(draws));

        currPlayer = new Player(textProfileName.getText().toString(), totalRice, gamesPlayed, wins, losses, draws, id);
        Intent i = getIntent();
        intentPlayer = (Player) i.getSerializableExtra(TicTacToeActivity.EXTRA_PLAYER_TICTACTOE);
        if (intentPlayer != null) {
            intentPlayer.setTotalRice(totalRice);
            intentPlayer.setGamesPlayed(gamesPlayed);
            intentPlayer.setWins(wins);
            intentPlayer.setLosses(losses);
            intentPlayer.setDraws(draws);
        }
        else {
            intentPlayer = currPlayer;
        }

        Log.d(TAG, "Displaying user info: \n" + currPlayer.displayInfo(TAG));
        Log.d(TAG, "Successfully retrieved preferences!");
    }

    private void setIntentPlayerData() {
        textTotalRiceDonated.setText(String.valueOf(intentPlayer.getTotalRice()));
        textGamesPlayed.setText(String.valueOf(intentPlayer.getGamesPlayed()));
        textWins.setText(String.valueOf(intentPlayer.getWins()));
        textLosses.setText(String.valueOf(intentPlayer.getLosses()));
        textDraws.setText(String.valueOf(intentPlayer.getDraws()));
        Log.d(TAG, "Successfully set data from intentPlayer!");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "OnActivityResult: requestCode is " + requestCode + " and resultCode is " + resultCode);
        // from sign up
        if (requestCode == 1 || resultCode == 100) {
            if (user != null) {
                Log.d(TAG, "OnActivityResult: from sign up");
                Intent i = getIntent();
                intentPlayer = (Player) i.getSerializableExtra(MainActivity.EXTRA_PLAYER_MAIN);

                //Player newPlayer = new Player();
                //newPlayer.setName(user.getDisplayName());
                //dr.child(user.getUid()).push().setValue(newPlayer);
                dr.child(user.getUid()).push().setValue(currPlayer);
                drUser = dr.child(user.getUid()).getRef();
                drUser.child("totalRice").push().setValue(0);

                textProfileName.setText(intentPlayer.getName());
                nameStr = intentPlayer.getName();
                /*
                Map<String, Object> userMap = new HashMap<>();
                userMap.put(user.getUid(), new Player());
                dr.updateChildren(userMap);
                */

                /*
                dr = database.getReference();
                dr.child("users").child(email).push();
                dr.child("users").child(user.getEmail()).setValue(currPlayer);
                */
            }
        }
        else if (requestCode == 3) {
            Log.d(TAG, "OnActivityResult: from login");
            Intent i = getIntent();
            intentPlayer = (Player) i.getExtras().getSerializable(LoginActivity.EXTRA_PLAYER_LOGIN);
            if (intentPlayer != null) {
                intentPlayer.displayInfo(TAG);
                setIntentPlayerData();
            }
            else {
                Log.d(TAG, "OnActivityResult: null player from login");
            }
        }
        else if (requestCode == 30) {
            Log.d(TAG, "OnActivityResult: from failed login");
        }
        else if (requestCode == 4) {
            Log.d(TAG, "OnActivityResult: from tictactoe -- retrieving preferences");
            retrievePreferences();
        }
        // from automatic sign in(2), login (3),
        else {
            if (requestCode == 2) { Log.d(TAG, "OnActivityResult: from automatic sign in"); }
            else if (requestCode == 5) { Log.d(TAG, "OnActivityResult: from leaderboard"); }
            /*
            drUser = dr.child(user.getUid()).getRef();
            drUser.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    Log.d(TAG, "OnActivityResult: from resultCode " + resultCode);

                    currPlayer = (Player) dataSnapshot.getValue(Player.class);
                    if (currPlayer == null) {
                        currPlayer = new Player();
                        currPlayer.setName(user.getDisplayName());
                        Log.d(TAG, "OnActivityResult: from resultCode " + resultCode + " - player is null");
                    }

                    textTotalRiceDonated.setText(String.valueOf(currPlayer.getTotalRice()));
                    textGamesPlayed.setText(String.valueOf(currPlayer.getGamesPlayed()));
                    textWins.setText(String.valueOf(currPlayer.getWins()));
                    textLosses.setText(String.valueOf(currPlayer.getLosses()));
                    textDraws.setText(String.valueOf(currPlayer.getDraws()));

                    Log.d(TAG, "OnActivityResult: onDataChange successful!");
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            */
        }
    }
}
