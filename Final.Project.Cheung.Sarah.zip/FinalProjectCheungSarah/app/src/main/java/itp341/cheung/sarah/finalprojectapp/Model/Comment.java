package itp341.cheung.sarah.finalprojectapp.Model;

public class Comment {
    String comment = "";

    public Comment(){
        super();
    }

    public Comment(String comment) {
        this.comment = comment;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

}
