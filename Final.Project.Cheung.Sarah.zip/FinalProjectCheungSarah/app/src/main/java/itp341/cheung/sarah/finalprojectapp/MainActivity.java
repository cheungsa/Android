package itp341.cheung.sarah.finalprojectapp;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ObjectStreamClass;
import java.io.Serializable;

import itp341.cheung.sarah.finalprojectapp.Model.Player;

// sign up activity
public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();
    public static final int RC_SIGN_IN = 1;
    public static final String EXTRA_PLAYER_MAIN = "com.itp341.cheung.sarah.finalprojectapp.player";
    public static final String ADMOB_ID = "ca-app-pub-6694345169411232~2736847660";

    private FirebaseAuth firebaseAuth;
    private FirebaseUser user;
    private DatabaseReference dr;
    private DatabaseReference drUser;
    private FirebaseDatabase database = null;
    private String emailString;
    private String passwordString;
    private String confirmPasswordString;
    private String nameString;
    private Uri photoUrl;

    EditText editEmail;
    EditText editPassword;
    EditText editConfirmPassword;
    EditText editUsername;
    Button buttonSignup;
    Button buttonLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // OAuth 2.0 Client ID: 843647173793-6l65sn17sa7b181lsks3qkbphnbjm9kd.apps.googleusercontent.com
        // OAuth Client ID: 417590597989-q64v423t4ca8323j0ig5dufv86r0dqme.apps.googleusercontent.com
        firebaseAuth = FirebaseAuth.getInstance();

        MobileAds.initialize(this, ADMOB_ID);

        editEmail = (EditText) findViewById(R.id.edit_email);
        editPassword = (EditText) findViewById(R.id.edit_password);
        editConfirmPassword = (EditText) findViewById(R.id.edit_confirm_password);
        editUsername = (EditText) findViewById(R.id.edit_username);
        buttonSignup = (Button) findViewById(R.id.button_sign_up);
        buttonLogin = (Button) findViewById(R.id.button_login);

        buttonSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailString = editEmail.getText().toString();
                String passwordString = editPassword.getText().toString();
                String confirmPasswordString = editConfirmPassword.getText().toString();
                String nameString = editUsername.getText().toString();

                registerUser(emailString, passwordString, confirmPasswordString, nameString);
            }
        });

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*
                Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                startActivityForResult(i, 1);
                */
                Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                startActivityForResult(i, 10);
                //setResult(10, i);
                //finish();
            }
        });

    }

    private void registerUser(final String email, String password, String confirmPassword, String name) {
        emailString = email;
        passwordString = password;
        confirmPasswordString = confirmPassword;
        nameString = name;

        Log.d(TAG, "Entered register user");

        if (TextUtils.isEmpty(emailString)) {
            Toast.makeText(this, "Please enter an email address", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(passwordString)) {
            Toast.makeText(this, "Please enter a password", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(confirmPasswordString)) {
            Toast.makeText(this, "Please confirm your password", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(nameString)) {
            Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!passwordString.equals(confirmPasswordString)) {
            Toast.makeText(this, "Passwords do not match!", Toast.LENGTH_SHORT).show();
            return;
        }

        Player newPlayer = new Player();
        firebaseAuth.createUserWithEmailAndPassword(emailString, passwordString)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Player newPlayer = new Player();
                        if (task.isSuccessful()) {
                            Log.d(TAG, "Sign up successful!");
                            Toast.makeText(getApplicationContext(), "Successfully signed up!", Toast.LENGTH_SHORT).show();

                            user = FirebaseAuth.getInstance().getCurrentUser();
                            newPlayer.setId(user.getUid());
                            Log.d(TAG, "Set user id: " + user.getUid());
                            if (user != null) {
                                Log.d(TAG, "Player is not null!");
                                UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                        .setDisplayName(editUsername.getText().toString())
                                        .build();

                                user.updateProfile(profileUpdates)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    Log.d(TAG, "User profile updated.");
                                                }
                                            }
                                        });

                                database = FirebaseDatabase.getInstance();
                                dr = database.getReference();
                                // inserting new user data into FB Realtime Database
                                dr.child(user.getUid()).push().setValue(newPlayer);
                                drUser = dr.child(user.getUid()).getRef();
                                drUser.child("totalRice").push().setValue(0);
                            }
                            else {
                                Log.d(TAG, "Player is null!");
                                Long uid = ObjectStreamClass.lookup(newPlayer.getClass()).getSerialVersionUID();
                                newPlayer.setId(String.valueOf(uid));
                            }

                            Intent i = new Intent(getApplicationContext(), ProfileActivity.class);
                            newPlayer.setName(editUsername.getText().toString());
                            i.putExtra(EXTRA_PLAYER_MAIN, newPlayer);
                            //startActivity(i);

                            Log.d(TAG, "Sign up successful! Set Intent");
                            //setResult(100, i);
                            //finish();
                            startActivityForResult(i, 1);
                        }
                        else {
                            Log.d(TAG, "Sign up failed!");
                            Toast.makeText(getApplicationContext(), "Sign up failed. Please try again!", Toast.LENGTH_SHORT).show();
                        }

                    }
                });

        Log.d(TAG, "Sign up failed outside!");

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "OnActivityResult from LoginActivity BackButton: requestCode is " + requestCode + " and resultCode is " + resultCode);
    }

}
