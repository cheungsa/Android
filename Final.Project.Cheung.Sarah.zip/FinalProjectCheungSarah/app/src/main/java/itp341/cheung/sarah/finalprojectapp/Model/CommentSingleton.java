package itp341.cheung.sarah.finalprojectapp.Model;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;

public class CommentSingleton {
    private static CommentSingleton singleton;
    private ArrayList<Comment> comments; // data source
    private Context context; // need the context (android-specific)

    // private singleton constructor
    private CommentSingleton() {
        comments = new ArrayList<Comment>();
    }

    // singleton get method
    public static CommentSingleton getSingleton() {
        if (singleton == null) {
            singleton = new CommentSingleton();
        }
        return singleton;
    }

    public int getNumComments() {
        return comments.size();
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public Comment getComment(int index) {
        if (index < 0 || index >= comments.size()) {
            Log.d("ERROR", "getMovie: index out of bounds");
            return null;
        }
        return comments.get(index);
    }

    public void addComment(Comment comment) {
        comments.add(comment);
    }

    public void removeComment(Comment comment) {
        comments.remove(comment);
    }

}
