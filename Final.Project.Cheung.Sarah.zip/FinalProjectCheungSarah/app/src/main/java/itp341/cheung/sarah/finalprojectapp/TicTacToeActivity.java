package itp341.cheung.sarah.finalprojectapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.view.Menu;
import android.view.MenuItem;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

import itp341.cheung.sarah.finalprojectapp.Model.Board;
import itp341.cheung.sarah.finalprojectapp.Model.BoardView;
import itp341.cheung.sarah.finalprojectapp.Model.Player;

public class TicTacToeActivity extends AppCompatActivity {
    private static final String TAG = TicTacToeActivity.class.getSimpleName();
    public static final String EXTRA_PLAYER_TICTACTOE = "com.itp341.cheung.sarah.finalprojectapp.playerTictactoe";
    public static final int RC_SIGN_IN = 1;

    private FirebaseUser user = null;
    private FirebaseDatabase database = null;
    private Player currPlayer = null;
    private DatabaseReference dr;
    private DatabaseReference drUser;

    private Button buttonQuit;
    private BoardView boardView;
    private Board board;
    private Intent iTicTacToe;
    private Player intentPlayer;

    private String id = "";
    private String name = "";
    private int totalRice = 0;
    private int gamesPlayed = 0;
    private int wins = 0;
    private int losses = 0;
    private int draws = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board);
        boardView = (BoardView) findViewById(R.id.board);
        board = new Board();
        boardView.setBoard(board);
        boardView.setTicTacToeActivity(this);

        buttonQuit = (Button) findViewById(R.id.button_quit_tictactoe);

        Intent i = getIntent();
        intentPlayer = (Player) i.getExtras().getSerializable(ProfileActivity.EXTRA_PLAYER_PROFILE);

        // if user is logged in
        user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            // get database
            database = FirebaseDatabase.getInstance();
            // FB database path must not contain '.'
            String email = user.getEmail().substring(0, user.getEmail().indexOf('.'));
            dr = database.getReference();
            drUser = dr.child(user.getUid()).getRef();
        }

        buttonQuit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "quit button was clicked!");
                Intent i = new Intent(getApplicationContext(), ProfileActivity.class);
                i.putExtra(EXTRA_PLAYER_TICTACTOE, intentPlayer);
                startActivityForResult(i, 4);
            }
        });
    }

    public void gameEnded(String s) {
        String msg = "";
        if (s == "D") {
            msg = "It's a draw!";
        }
        else if (s == "O") {
            msg = "Congrats, you won!";
        }
        else {
            msg = "Sorry, you lost...";
        }

        updatePlayerData(s);

        new AlertDialog.Builder(this).setTitle("Tic Tac Toe").
                setMessage(msg).
                setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialogInterface) {
                        newGame();
                    }
                }).show();
    }

    private void newGame() {
        Log.d(TAG, "~~~~~~~~~~~~~~~New game!~~~~~~~~~~~~~~~\n" + currPlayer.displayInfo(TAG));
        Log.d(TAG, "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        board.newGame();
        boardView.invalidate();
    }

    private void updatePlayerData(String s) {
        gamesPlayed++;
        if (s == "D") {
            // tie
            draws++;
            totalRice += 10;
        }
        else if (s == "O") {
            // player won
            wins++;
            totalRice += 20;
        } else if (s == "X") {
            // computer won
            losses++;
            totalRice += 5;
        }
        Log.d(TAG, "\nUpdating player data for " + user.getDisplayName() + ":" +
                "\n(1) Games played: " + gamesPlayed +
                "\n(2) Total Rice: " + totalRice +
                "\n(3) Wins: " + wins +
                "\n(4) Losses: " + losses +
                "\n(5) Draws: " + draws +
                "\n(6) Id: " + id);
        savePreferences();
        currPlayer = new Player(name, totalRice, gamesPlayed, wins, losses, draws, id);
        intentPlayer = new Player(name, totalRice, gamesPlayed, wins, losses, draws, id);
        drUser.setValue(currPlayer);
    }

    private void retrievePreferences() {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        id = preferences.getString("Id", "");
        name = preferences.getString("Name", "");
        totalRice = preferences.getInt("Rice", 0);
        gamesPlayed = preferences.getInt("Games", 0);
        wins = preferences.getInt("Wins", 0);
        losses = preferences.getInt("Losses", 0);
        draws = preferences.getInt("Draws", 0);

        Log.d(TAG, "Successfully retrieved preferences!");
    }

    private void savePreferences(){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("Id", id);
        editor.putString("Name", name);
        editor.putInt("Rice", totalRice);
        editor.putInt("Games", gamesPlayed);
        editor.putInt("Wins", wins);
        editor.putInt("Losses", losses);
        editor.putInt("Draws", draws);
        editor.apply();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // from profile
        if (requestCode == 1) {
            Log.d(TAG, "OnActivityResult: came from ProfileActivity");
            totalRice = iTicTacToe.getIntExtra(ProfileActivity.EXTRA_PLAYER_RICE, 0);
            gamesPlayed = iTicTacToe.getIntExtra(ProfileActivity.EXTRA_PLAYER_GAMES, 0);
            wins = iTicTacToe.getIntExtra(ProfileActivity.EXTRA_PLAYER_WINS, 0);
            losses = iTicTacToe.getIntExtra(ProfileActivity.EXTRA_PLAYER_LOSSES, 0);
            draws = iTicTacToe.getIntExtra(ProfileActivity.EXTRA_PLAYER_DRAWS, 0);
        }

        Log.d(TAG, "OnActivityResult: retrieving preferences");
        retrievePreferences();
    }
}
